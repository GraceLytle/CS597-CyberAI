This folder contains the backend for the actual network evaluations.
All implementations should inherit from ```victim_base``` and implement the methods exposed there.